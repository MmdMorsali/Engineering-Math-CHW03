%% section 4.1 -https://www.mathworks.com/help/images/exploring-a-conformal-mapping.html;jsessionid=0282e86d2866ef42e13b0c32bb00
clear; clc; close all;

 A = imread('lines.png');
 A = A(1:345,1:819,:);

 figure
 subplot(121)
 imshow(A)
 hold on
 title('Original Image','FontSize',14)
 conformal = maketform('custom', 2, 2, [], @conformalInverse, []);
 type conformalInverse.m
%function U = conformalInverse(X, ~)
%Z = complex(X(:,1),X(:,2));
%W = 1./Z;
%U(:,2) = imag(W);
%U(:,1) = real(W);
xData = [ -3    3 ];  % Bounds for REAL(z)
yData = [  2   -2 ];  % Bounds for IMAG(z)
uData = [ -2.4   2.4];  % Bounds for REAL(w)
vData = [  1.5  -1.5];  % Bounds for IMAG(w)

B = imtransform( A, conformal, 'cubic', ...
                'UData', uData,'VData', vData,...
                'XData', xData,'YData', yData,...
                'Size', [300 360], 'FillValues', 255 );
subplot(122)
imshow(B)
title('Transformed Image','FontSize',14)


%% section 4.2

clear; clc; close all;

 A = imread('strawberry.png');
 A = A(1:163,1:299,:);

 figure
 subplot(121)
 imshow(A)
 hold on
 title('Original Image','FontSize',14)
 
type conformalInverseClip.m
ring = maketform('custom', 2, 2, [], @conformalInverseClip, []);

uData = [ -1.25   1.25];  % Bounds for REAL(w)
vData = [  0.75  -0.75];  % Bounds for IMAG(w)
xData = [ -2.4    2.4 ];  % Bounds for REAL(z)
yData = [  2.0   -2.0 ];  % Bounds for IMAG(z)


B = imtransform( A, ring, 'cubic',...
                    'UData', uData,  'VData', vData,...
                    'XData', [-2 2], 'YData', yData,...
                    'Size', [400 400], 'FillValues', 255 );
subplot(122)
imshow(B)
title('Transformed Image','FontSize',14)