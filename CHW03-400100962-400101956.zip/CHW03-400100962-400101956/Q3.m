%% Q3-first Integral
%clc; clear; close all;
temp_1 = @(z) cos(z)./(z.*(z.^2+8));
g = @(phi) 3*(cos(phi)+2/3 + 1i*sin(phi));
cog = @(phi) 3*(-sin(phi) + 1i*cos(phi));
disp("the value of I_1 is = "+string(integral(@(t) temp_1(g(t)).*cog(t),0,2*pi)));
%% Q2-Second Integral
%clear; clc; close all;
syms theta t z
g= @(z) sinh(z)/(z.^4);
cog = @(theta) exp(1i * theta);
disp("the value of I_2 is = "+string(1i*integral(@(theta) g(cog(theta)).*exp(1i*theta) , 0 , 2*pi)));
%% Q3-Third Integral 
%clear; clc; close all;
temp_3= @(z) (1-exp(z))./(z.^2.*(z-1).*(z-1));
g = @(theta) 2*(cos(theta) + 1i*sin(theta));
cog = @(theta) 2*(-sin(theta) + 1i*cos(theta));
disp("the value of I_3 is ="+string(integral(@(t) temp_3(g(t)).*cog(t),0,2*pi)));
%% Q3-Function
function df = functionCauchyDerivative(f,z0,n)
syms g theta
g = @(theta) exp(1i*theta) + z0;
te = @(g) ((g - z0).*f(g))./((g - z0).^(n+1));
In = integral(@(theta) te(g(theta)) , 0 , 2*pi);
df = (factorial(n)./(2*pi)).*In;
end