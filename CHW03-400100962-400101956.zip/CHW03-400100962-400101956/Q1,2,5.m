%% section 1

clear ; clc ; close all ; 
syms z ;
pos1 = [0.1 0.6 0.35 0.35];
pos2 = [0.1 0.1 0.35 0.35];
pos3 = [0.6 0.6 0.35 0.35];
pos4 = [0.6 0.1 0.35 0.35];

% part 1 f

f = sinh(log(z.^2+1))-(1*i)^(1*i) == 0;
answer = double(solve(f,z))
subplot('position',pos1)
zplane(answer)
grid on
title('f(z)')

% part 1 g

g = z.^7-2*z+1 == 0;
answer = double(solve(g,z))
subplot('position',pos2)
zplane(answer)
grid on
title('g(z)')

% part 1 h

h = cos(sqrt(4)*z)-(1*i)^(1*i)+(2*i) == 0;
answer = double(solve(h,z))
subplot('position',pos3)
zplane(answer)
grid on
title('h(z)')

% part 1 l

l = cosh(z.^2)-sqrt(2*i) == 0;
answer = double(solve(l,z))
subplot('position',pos4)
zplane(answer)
grid on
title('l(z)')

%% section 2

clear ; clc ; close all;

syms x y real;

z = x + 1i*y;

f = sinc(z^2/2);
g = 1/z;
h = (z)^5+(z)^2+1 ;
l = z + exp(z*1i);

% part 1

% showing real/imaginary parts of the functions

disp('real part f')
disp(real(f))
disp('imaginary part f')
disp(imag(f))
disp('real part g')
disp(real(g))
disp('imaginary part g')
disp(imag(g))
disp('real part h')
disp(real(h))
disp('imaginary part h')
disp(imag(h))
disp('real part l')
disp(real(l))
disp('imaginary part l')
disp(imag(l))

% check if functions are harmonic with laplace equation

disp('real f --> fxx + fyy')
check1 = diff(diff(real(f),x),x) + diff(diff(real(f),y),y);
disp(check1)
disp('imaginary f --> fxx + fyy')
check2 = diff(diff(imag(f),x),x) + diff(diff(imag(f),y),y);
disp(check2)
if (check1==0)&&(check2==0)
    disp('f is harmonic')
else
    disp('f is not harmonic')
end
disp('real g --> gxx + gyy')
check1 = diff(diff(real(g),x),x) + diff(diff(real(g),y),y);
disp(check1)
disp('imaginary g --> gxx + gyy')
check2 = diff(diff(imag(g),x),x) + diff(diff(imag(g),y),y);
disp(check2)
if (check1==0)&&(check2==0)
    disp('g is harmonic')
else
    disp('g is not harmonic')
end
disp('real h --> hxx + hyy')
check1 = diff(diff(real(h),x),x) + diff(diff(real(h),y),y);
disp(check1)
disp('imaginary h --> hxx + hyy')
check2 = diff(diff(imag(h),x),x) + diff(diff(imag(h),y),y);
disp(check2)
if (check1==0)&&(check2==0)
    disp('h is harmonic')
else
    disp('h is not harmonic')
end
disp('real l --> lxx + lyy')
check1 = diff(diff(real(l),x),x) + diff(diff(real(l),y),y);
disp(check1)
disp('imaginary l --> lxx + lyy')
check2 = diff(diff(imag(l),x),x) + diff(diff(imag(l),y),y);
disp(check2)
if (check1==0)&&(check2==0)
    disp('l is harmonic')
else
    disp('l is not harmonic')
end

% part 2

disp('f : Ux - Vy')
check3 = diff(real(f),x) - diff(imag(f),y);
disp(check3)
disp('f : Uy + Vx')
check4 = diff(imag(f),x) + diff(real(f),y);
disp(check4)
if (check3 == 0)&&(check4 == 0)
    disp('f tahlili')
else
    disp('f tahlili nist')
end
disp('g : Ux - Vy')
check3 = diff(real(g),x) - diff(imag(g),y);
disp(check3)
disp('g : Uy + Vx')
check4 = diff(imag(g),x) + diff(real(g),y);
disp(check4)
if (check3 == 0)&&(check4 == 0)
    disp('g tahlili')
else
    disp('g tahlili nist')
end
disp('h : Ux - Vy')
check3 = diff(real(h),x) - diff(imag(h),y);
disp(check3)
disp('h : Uy + Vx')
check4 = diff(imag(h),x) + diff(real(h),y);
disp(check4)
if (check3 == 0)&&(check4 == 0)
    disp('h tahlili')
else
    disp('h tahlili nist')
end
disp('l : Ux - Vy')
check3 = diff(real(l),x) - diff(imag(l),y);
disp(check3)
disp('l : Uy + Vx')
check4 = diff(imag(l),x) + diff(real(l),y);
disp(check4)
if (check3 == 0)&&(check4 == 0)
    disp('l tahlili')
else
    disp('l tahlili nist')
end

% faghat  h va l tahlili hastand va moshtagh anha ra rasm mikonim

% first we need to know Ux and Vx for functions h and l on the syms x and y
% to plot the derivation

disp(diff(real(h),x));
disp(diff(imag(h),x));
disp(diff(real(l),x));
disp(diff(imag(l),x));

figure(1)

subplot(1,2,1)
x = -40:0.1:40;
y = -40:0.1:40;
plot(2.*x + x.*(x.*(x.^2 - y.^2) - 2.*x.*y.^2) - y.*(y.*(x.^2 - y.^2) + 2.*x.^2.*y) + x.*(x.*(x.^2 - y.^2) + x.*(3.*x.^2 - 3.*y.^2) - 8.*x.*y.^2) - y.*(y.*(x.^2 - y.^2) + y.*(3.*x.^2 - 3.*y.^2) + 8.*x.^2.*y),2.*y + x.*(y.*(x.^2 - y.^2) + 2.*x.^2.*y) + y.*(x.*(x.^2 - y.^2) - 2.*x.*y.^2) + y.*(x.*(x.^2 - y.^2) + x.*(3.*x.^2 - 3.*y.^2) - 8.*x.*y.^2) + x.*(y.*(x.^2 - y.^2) + y.*(3.*x.^2 - 3.*y.^2) + 8.*x.^2.*y))
xlim([-40 40])
ylim([-20 20])
title('h')

subplot(1,2,2)
x = linspace(-40, 40, 500);
y = linspace(-10, 10, 500);
plot(1 - exp(-y).*sin(x),exp(-y).*cos(x))
xlim([-20 20])
ylim([-10 10])
title('l')

% with changing linspace range and lim for plotting lables the shape of the
% output will change widely

% part 3 

% for plotting for some c and k coefficients we can use fcontour 
% here we use real and img parts of h and l which we have from part 1
syms x y
figure(2)
subplot(2,2,1)
% u(x,y) = c for function h
fcontour(x*(x*(x*(x^2 - y^2) - 2*x*y^2) - y*(y*(x^2 - y^2) + 2*x^2*y)) - y*(x*(y*(x^2 - y^2) + 2*x^2*y) + y*(x*(x^2 - y^2) - 2*x*y^2)) + x^2 - y^2 + 1);
title('h : u(x,y) = c')

subplot(2,2,2)
% v(x,y) = k for function h
fcontour(2*x*y + x*(x*(y*(x^2 - y^2) + 2*x^2*y) + y*(x*(x^2 - y^2) - 2*x*y^2)) + y*(x*(x*(x^2 - y^2) - 2*x*y^2) - y*(y*(x^2 - y^2) + 2*x^2*y)));
title('h : v(x,y) = k')

subplot(2,2,3)
% u(x,y) = c for function l
fcontour(x + exp(-y)*cos(x));
title('l : u(x,y) = c')

subplot(2,2,4)
% v(x,y) = k for function l
fcontour(y + exp(-y)*sin(x));
title('l : v(x,y) = k')


%% section 5 part 1

clear ; clc ; close all;

c = 0 + 1i;

x = linspace(-2.000, 2.000, 1000);
y = linspace(2.000, -2.000, 1000);
z = bsxfun(@plus, x(:), (y(:) * 1i)');
mat = inf(size(z));                              

for iteration = 1:1000
    z(~isinf(z)) = z(~isinf(z)).^2 + c; 
    mat(isinf(mat) & isinf(z)) = iteration;
end

plot = imagesc(mat');

%% section 5 part 2

clear ; clc ; close all;

n = 2 ; 
c = -1 ;

x = linspace(-2.000, 2.000, 1000);
y = linspace(2.000, -2.000, 1000);
z = bsxfun(@plus, x(:), (y(:) * 1i)');
mat = inf(size(z));                              

for iteration = 1:1000
    z(~isinf(z)) = z(~isinf(z)).^n + c; 
    mat(isinf(mat) & isinf(z)) = iteration;
end

figure(1)
plot = imagesc(mat');

n = 2 ; 
c = -0.6+0.8i ;

x = linspace(-2.000, 2.000, 1000);
y = linspace(2.000, -2.000, 1000);
z = bsxfun(@plus, x(:), (y(:) * 1i)');
mat = inf(size(z));                              

for iteration = 1:1000
    z(~isinf(z)) = z(~isinf(z)).^n + c; 
    mat(isinf(mat) & isinf(z)) = iteration;
end

figure(2)
plot = imagesc(mat');

n = 4 ;
c = 0.4 ;

x = linspace(-2.000, 2.000, 1000);
y = linspace(2.000, -2.000, 1000);
z = bsxfun(@plus, x(:), (y(:) * 1i)');
mat = inf(size(z));                              

for iteration = 1:1000
    z(~isinf(z)) = z(~isinf(z)).^n + c; 
    mat(isinf(mat) & isinf(z)) = iteration;
end

figure(3)
plot = imagesc(mat');

n = 4 ;
c = 0.8 + 0.2i;

x = linspace(-2.000, 2.000, 1000);
y = linspace(2.000, -2.000, 1000);
z = bsxfun(@plus, x(:), (y(:) * 1i)');
mat = inf(size(z));                              

for iteration = 1:1000
    z(~isinf(z)) = z(~isinf(z)).^n + c; 
    mat(isinf(mat) & isinf(z)) = iteration;
end

figure(4)
plot = imagesc(mat');

n = 4 ; 
c = -1 ;

x = linspace(-2.000, 2.000, 1000);
y = linspace(2.000, -2.000, 1000);
z = bsxfun(@plus, x(:), (y(:) * 1i)');
mat = inf(size(z));                              

for iteration = 1:1000
    z(~isinf(z)) = z(~isinf(z)).^n + c; 
    mat(isinf(mat) & isinf(z)) = iteration;
end

figure(5)
plot = imagesc(mat');