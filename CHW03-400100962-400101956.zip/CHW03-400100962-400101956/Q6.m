%% Q6
clc; clear;
syms x y z
assume(x,'real')
assume(y,'real')
z=(x+1i*y);
u1=x+exp(y)*cos(x);
u2=exp(x)*(x*cos(y)-y*sin(y));
u3=exp(-2*y*x)*(x*sin(y)-y*cos(y));
u4=exp(-x)*sin(x*x-y*y);
v1=y-exp(y)*sin(x);
v2=exp(x)*(y*cos(y)+x*sin(y));
figure
%func(u1,v1,6)
func(u2,v2,6)

function func(u,v,n)

fcontour(u,[-n n -n n],"LineWidth",1,LineColor=[0.85 0.33 0.098])
hold on
grid on
fcontour(v ,[-n n -n n],"LineWidth",1,LineColor=[0 0.45 0 0.74])
text(07*n , 1.05*n , 'u(x,y)=C', 'Color',[0.8500 0.3250 0.0980],'FontSize',10,'HorizontalAlignment','left')
text(07*n , 1.05*n , 'v(x,y)=K', 'Color',[0.8500 0.4470 0.7410],'FontSize',10,'HorizontalAlignment','left')
end